const express = require('express');
const app = express();
app.use(express.urlencoded({extended:true}));

app.get('/', (req,res)=>{
    res.send(`
        <h2>Think New SMS Login</h2>
        <form method="POST" action="/login">
        <input name="username"/><br>
        <input type="password" name="password"/><br>
        <button>Login</button>
        </form>
    `);
});

app.post('/login', (req,res)=>{
    if(req.body.username==="Think" && req.body.password==="Think143"){
        res.send("<h2>Welcome to Think New SMS Dashboard</h2>");
    } else {
        res.send("Invalid login");
    }
});

app.listen(3000, ()=>console.log("Server running"));
